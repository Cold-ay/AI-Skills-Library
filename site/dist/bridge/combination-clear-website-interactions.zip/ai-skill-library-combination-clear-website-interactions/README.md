# Skill Bridge: Clear website interactions

1. Review install.py, PACKAGE.json and every payload file. Compare the ZIP SHA-256 with the website. Hashes check integrity, not publisher authenticity.
2. Extract this entire folder. In a terminal, change to this folder. Python 3.9+ is required; no pip installation or network is needed.
3. Preview: python3 install.py --platform codex --scope project --project "/absolute/path/to/project"
4. After reviewing: repeat that command with --reviewed. Choose claude or cursor for those local clients; --scope user installs to the current user instead. On Windows use py -3 instead of python3.
5. Open a new chat in the target project, confirm the skill is available, and use $combination-clear-website-interactions <your task> in Codex, or /combination-clear-website-interactions <your task> in Claude Code / Cursor. If native discovery is unavailable, explicitly ask the agent to read the installed SKILL.md.

Destinations: Codex .agents/skills; Claude Code .claude/skills; Cursor .cursor/skills. Project scope uses the selected project; user scope uses the home directory. Cloud accounts and remote workers are not synced.

Existing folders are never replaced or merged. If there is a collision, use the existing installation or review a separate project. No settings, CLAUDE.md, AGENTS.md, hooks, scripts or dependencies are executed/modified by the installer. Upstream instructions are unmodified; the combination wrapper is library-authored and staged. Installing instruction files does not establish runtime compatibility.

## Requirements

A website or prototype with a specific task. Plain HTML/CSS/JavaScript works; no animation runtime or service is bundled. Review source before use; preserve existing project instructions.
