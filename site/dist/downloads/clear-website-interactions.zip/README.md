# Clear website interactions

Make controls discoverable, then specify honest feedback and recovery states.

Review all files before use. Extract into a clean staging directory, then copy .agents/skills into your project after checking for collisions. No packages or dependencies are installed by extraction. Start a new Codex session and explicitly invoke `$combination-clear-website-interactions <your task>`. For Claude Code, copy or merge the included CLAUDE.md into the project root without replacing existing instructions, keep .agents/skills alongside it, and explicitly ask Claude to read the combination SKILL.md. This adapter uses file references, not native slash-command discovery. The workflow sequences skills; simultaneous execution and runtime compatibility in either host are untested.

A website or prototype with a specific task. Plain HTML/CSS/JavaScript works; no animation runtime or service is bundled. Review source before use; preserve existing project instructions.

Design of Everyday Things owns discoverability and task flow; Microinteractions owns local feedback within that flow. Optional sibling skills are not bundled. Numeric self-scores and user-study percentages are heuristics, not test results. Never show success before the real operation succeeds or infer that copying a command ran it.

Original upstream files remain unmodified and retain their licenses. The orchestration text is library-authored. ZIPs contain instruction text and may contain passive scripts; nothing was executed to build them.
