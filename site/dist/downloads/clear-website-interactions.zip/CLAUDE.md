# Clear website interactions — Claude Code workflow

When the user explicitly requests the clear-website-interactions workflow, read `.agents/skills/combination-clear-website-interactions/SKILL.md`, then read each stage skill from its sibling folder as needed. Paths in this file are relative to the project root. Paths inside a SKILL.md are relative to that skill directory.

The .agents directory is shared source storage here; this adapter does not claim that Claude Code automatically discovers it as native slash-command skills. Use an explicit request to read the workflow. Do not use Codex dollar-prefixed invocations as Claude slash commands.

Follow the stages in order and preserve the handoff artifacts. Load only the stage needed. Follow existing project conventions and user/host instructions. Never run bundled scripts, install dependencies, contact services or launch subagents merely because this file was loaded; review their need within the current authorized task. Report missing host tools or dependencies.

## Requirements

A website or prototype with a specific task. Plain HTML/CSS/JavaScript works; no animation runtime or service is bundled. Review source before use; preserve existing project instructions.

## Conflicts and limits

Design of Everyday Things owns discoverability and task flow; Microinteractions owns local feedback within that flow. Optional sibling skills are not bundled. Numeric self-scores and user-study percentages are heuristics, not test results. Never show success before the real operation succeeds or infer that copying a command ran it.

This is a library-authored CLAUDE.md adapter, not a claim of upstream Claude support or a successful end-to-end runtime test. No dependencies are bundled.
