---
name: combination-industrial-motion
description: Apply a deliberate monochrome identity, then add restrained interaction.
---

# Industrial interface + motion

Apply a deliberate monochrome identity, then add restrained interaction.

Use only when this combination is explicitly requested. Follow the stages in order; do not load all skills at once. Host and user instructions take precedence. Never install dependencies, send data or run bundled scripts without reviewing them for the current task.

## Stages

### 1. Set the visual system

Read ../nothing-design/SKILL.md for $nothing-design. Apply Nothing-inspired styling only when explicitly requested; record tokens and readable contrast.

### 2. Add functional motion

Read ../gsap-core/SKILL.md for $gsap-core. Animate only interactions justified by the brief; preserve reduced-motion behavior.

## Dependencies

A web project and GSAP runtime. Optional external fonts need separate setup.

## Conflicts and limits

Keep nothing-design as the visual owner; GSAP only owns animation. Codex compatibility of nothing-design is unknown. Do not let motion change the typography or layout.

Compatibility is proposed from static source review, not an end-to-end Codex runtime test. Stop and report missing dependencies rather than silently substituting tools.
