# Industrial interface + motion — Claude Code workflow

When the user explicitly requests the industrial-motion workflow, read `.agents/skills/combination-industrial-motion/SKILL.md`, then read each stage skill from its sibling folder as needed. Paths in this file are relative to the project root. Paths inside a SKILL.md are relative to that skill directory.

The .agents directory is shared source storage here; this adapter does not claim that Claude Code automatically discovers it as native slash-command skills. Use an explicit request to read the workflow. Do not use Codex dollar-prefixed invocations as Claude slash commands.

Follow the stages in order and preserve the handoff artifacts. Load only the stage needed. Follow existing project conventions and user/host instructions. Never run bundled scripts, install dependencies, contact services or launch subagents merely because this file was loaded; review their need within the current authorized task. Report missing host tools or dependencies.

## Requirements

A web project and GSAP runtime. Optional external fonts need separate setup.

## Conflicts and limits

Keep nothing-design as the visual owner; GSAP only owns animation. Codex compatibility of nothing-design is unknown. Do not let motion change the typography or layout.

This is a library-authored CLAUDE.md adapter, not a claim of upstream Claude support or a successful end-to-end runtime test. No dependencies are bundled.
