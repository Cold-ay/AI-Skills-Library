# Industrial interface + motion

Apply a deliberate monochrome identity, then add restrained interaction.

Review all files before use. Extract into a clean staging directory, then copy .agents/skills into your project after checking for collisions. No packages or dependencies are installed by extraction. Start a new Codex session and explicitly invoke `$combination-industrial-motion <your task>`. For Claude Code, copy or merge the included CLAUDE.md into the project root without replacing existing instructions, keep .agents/skills alongside it, and explicitly ask Claude to read the combination SKILL.md. This adapter uses file references, not native slash-command discovery. The workflow sequences skills; simultaneous execution and runtime compatibility in either host are untested.

A web project and GSAP runtime. Optional external fonts need separate setup.

Keep nothing-design as the visual owner; GSAP only owns animation. Codex compatibility of nothing-design is unknown. Do not let motion change the typography or layout.

Original upstream files remain unmodified and retain their licenses. The orchestration text is library-authored. ZIPs contain instruction text and may contain passive scripts; nothing was executed to build them.
