# Evidence to editorial report — Claude Code workflow

When the user explicitly requests the evidence-to-article workflow, read `.agents/skills/combination-evidence-to-article/SKILL.md`, then read each stage skill from its sibling folder as needed. Paths in this file are relative to the project root. Paths inside a SKILL.md are relative to that skill directory.

The .agents directory is shared source storage here; this adapter does not claim that Claude Code automatically discovers it as native slash-command skills. Use an explicit request to read the workflow. Do not use Codex dollar-prefixed invocations as Claude slash commands.

Follow the stages in order and preserve the handoff artifacts. Load only the stage needed. Follow existing project conventions and user/host instructions. Never run bundled scripts, install dependencies, contact services or launch subagents merely because this file was loaded; review their need within the current authorized task. Report missing host tools or dependencies.

## Requirements

User-provided sources; frontend tooling for article output. No database retrieval, paid figures or TTS is included.

## Conflicts and limits

Critical-thinking owns claim strength; article design must not inflate certainty. Optional sibling skills are excluded. This is not a clinical recommendation workflow.

This is a library-authored CLAUDE.md adapter, not a claim of upstream Claude support or a successful end-to-end runtime test. No dependencies are bundled.
