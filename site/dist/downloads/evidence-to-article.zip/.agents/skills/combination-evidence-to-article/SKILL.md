---
name: combination-evidence-to-article
description: Evaluate provided evidence before turning it into a readable web report.
---

# Evidence to editorial report

Evaluate provided evidence before turning it into a readable web report.

Use only when this combination is explicitly requested. Follow the stages in order; do not load all skills at once. Host and user instructions take precedence. Never install dependencies, send data or run bundled scripts without reviewing them for the current task.

## Stages

### 1. Appraise supplied evidence

Read ../scientific-critical-thinking/SKILL.md for $scientific-critical-thinking. Create a source/claim/limitation table from user-provided papers; core appraisal only, no optional schematic service.

### 2. Publish the bounded conclusions

Read ../beautiful-article/SKILL.md for $beautiful-article. Use the approved evidence table to build an editorial article; keep uncertainty, references and missing evidence visible.

## Dependencies

User-provided sources; frontend tooling for article output. No database retrieval, paid figures or TTS is included.

## Conflicts and limits

Critical-thinking owns claim strength; article design must not inflate certainty. Optional sibling skills are excluded. This is not a clinical recommendation workflow.

Compatibility is proposed from static source review, not an end-to-end Codex runtime test. Stop and report missing dependencies rather than silently substituting tools.
