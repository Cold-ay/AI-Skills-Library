# Evidence to editorial report

Evaluate provided evidence before turning it into a readable web report.

Review all files before use. Extract into a clean staging directory, then copy .agents/skills into your project after checking for collisions. No packages or dependencies are installed by extraction. Start a new Codex session and explicitly invoke `$combination-evidence-to-article <your task>`. For Claude Code, copy or merge the included CLAUDE.md into the project root without replacing existing instructions, keep .agents/skills alongside it, and explicitly ask Claude to read the combination SKILL.md. This adapter uses file references, not native slash-command discovery. The workflow sequences skills; simultaneous execution and runtime compatibility in either host are untested.

User-provided sources; frontend tooling for article output. No database retrieval, paid figures or TTS is included.

Critical-thinking owns claim strength; article design must not inflate certainty. Optional sibling skills are excluded. This is not a clinical recommendation workflow.

Original upstream files remain unmodified and retain their licenses. The orchestration text is library-authored. ZIPs contain instruction text and may contain passive scripts; nothing was executed to build them.
