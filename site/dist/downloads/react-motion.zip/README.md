# React motion studio

Build scoped, sequenced React animations with lifecycle cleanup.

Review all files before use. Extract into a clean staging directory, then copy .agents/skills into your project after checking for collisions. No packages or dependencies are installed by extraction. Start a new Codex session and explicitly invoke `$combination-react-motion <your task>`. The workflow sequences skills; simultaneous execution and runtime compatibility are untested.

React, gsap and @gsap/react. Runtime library terms are separate from skill MIT licenses.

Core examples do not override React lifecycle guidance. Use gsap-react cleanup in React. ScrollTrigger and other plugins are outside this pack.

Original upstream files remain unmodified and retain their licenses. The orchestration text is library-authored. ZIPs contain instruction text and may contain passive scripts; nothing was executed to build them.
