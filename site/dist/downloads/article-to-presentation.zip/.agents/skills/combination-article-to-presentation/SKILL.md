---
name: combination-article-to-presentation
description: Create an editorial web article and adapt its evidence into a presentation.
---

# Article to presentation

Create an editorial web article and adapt its evidence into a presentation.

Use only when this combination is explicitly requested. Follow the stages in order; do not load all skills at once. Host and user instructions take precedence. Never install dependencies, send data or run bundled scripts without reviewing them for the current task.

## Stages

### 1. Produce the source article

Read ../beautiful-article/SKILL.md for $beautiful-article. Write the approved article with traceable claims and export a stable content outline.

### 2. Adapt to presentation scenes

Read ../web-video-presentation/SKILL.md for $web-video-presentation. Use that outline as input; review story, scene outline and rendered presentation at separate checkpoints.

## Dependencies

Vite, React and TypeScript for generated projects. Optional TTS requires separate services; source skills are Chinese.

## Conflicts and limits

Pass an article/outline between stages, not conflicting project scaffolds. Use separate output directories. Adapt upstream agent/reviewer instructions to your host; do not assume subagents or voice services exist.

Compatibility is proposed from static source review, not an end-to-end Codex runtime test. Stop and report missing dependencies rather than silently substituting tools.
