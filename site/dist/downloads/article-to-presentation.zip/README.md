# Article to presentation

Create an editorial web article and adapt its evidence into a presentation.

Review all files before use. Extract into a clean staging directory, then copy .agents/skills into your project after checking for collisions. No packages or dependencies are installed by extraction. Start a new Codex session and explicitly invoke `$combination-article-to-presentation <your task>`. The workflow sequences skills; simultaneous execution and runtime compatibility are untested.

Vite, React and TypeScript for generated projects. Optional TTS requires separate services; source skills are Chinese.

Pass an article/outline between stages, not conflicting project scaffolds. Use separate output directories. Adapt upstream agent/reviewer instructions to your host; do not assume subagents or voice services exist.

Original upstream files remain unmodified and retain their licenses. The orchestration text is library-authored. ZIPs contain instruction text and may contain passive scripts; nothing was executed to build them.
